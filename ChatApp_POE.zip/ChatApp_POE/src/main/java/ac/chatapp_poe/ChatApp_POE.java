/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ac.chatapp_poe;

import java.util.regex.Pattern;

/**
 *
 * @author Lungelo
 */
public class ChatApp_POE {

  

    // South African cell number: '+27' followed by 9 digits (matches a local 0-number
    // with the leading 0 replaced by the country code), e.g. +27838968976.
    private static final Pattern CELLPHONE_PATTERN = Pattern.compile(
            "^\\+27[0-9]{9}$"
    );

    // --- Validation methods --------------------------------------------------

    /**
     * A valid username contains an underscore and is no more than five
     * characters long in total.
     * @param username
     * @return 
     */
    public boolean checkUserName(String username) {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * A valid password is at least 8 characters long and contains a capital
     * letter, a number, and a special character.
     * @param password
     * @return 
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        return PASSWORD_PATTERN.matcher(password).matches();
    }

    /**
     * A valid cell number starts with the South African international code
     * (+27) followed by the 9-digit local number.
     * @param cellPhoneNumber
     * @return 
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) return false;
        return CELLPHONE_PATTERN.matcher(cellPhoneNumber).matches();
    }

    // --- Registration ----------------------------------------------------

    /**
     * Validates and registers a new user, returning the exact status message
     * for whichever condition applies.
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param cellPhoneNumber
     * @return 
     */
    public String registerUser(String firstName, String lastName, String username,
                                String password, String cellPhoneNumber) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your "
                    + "username contains an underscore and is no more than five "
                    + "characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the "
                    + "password contains at least eight characters, a capital "
                    + "letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain "
                    + "international code; please correct the number and try again.";
        }

        registeredUsers.add(new User(firstName, lastName, username, password, cellPhoneNumber));
        return "Username successfully captured. Password successfully captured. "
                + "Cell phone number successfully added. Registration complete.";
    }

    // --- Login -------------------------------------------------------------

    /**
     * Checks the given username/password against the stored registration
     * details for that username.
     * @param username
     * @param password
     * @return 
     */
    public boolean loginUser(String username, String password) {
        Iterable<User> registeredUsers = null;
        for (User user : registeredUsers) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    /** Looks up a registered user by username, or null if not found.
     * @param username
     * @return  */
    public User findUserByUsername(String username) {
        Iterable<User> registeredUsers = null;
        for (User user : registeredUsers) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Builds the message shown after a login attempt.
     * Pass the result of loginUser(), plus the matching user's first/last name
     * (look them up with findUserByUsername() first).
     */
    public String returnLoginStatus(boolean loginSuccessful, String firstName, String lastName) {
        if (loginSuccessful) {
            return "Welcome " + firstName + ", " + lastName + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}

}
